from get_database import get_database

def save_data(game_data):
    dbname = get_database()
    collection_name = dbname["game_1_data"]
    
    game_data = eval(game_data)
    collection_name.insert_one(game_data)