import pika
from mongo_query import query_data
from mongo_insert import save_data

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='localhost'))

channel = connection.channel()

channel.queue_declare(queue='game_queue6')

def on_request(ch, method, props, game_id):
    
    game_string = game_id.decode('utf-8', errors='ignore')

    # if retrieving a saved game
    if game_string.find("Game_Id:") >= 0:
        game_string_id = game_string.split(":")
        game_num = int(game_string_id[1].strip())
        response = query_data(game_num)
    # if saving a game
    else:
        response = save_data(game_id)

    ch.basic_publish(exchange='',
                     routing_key=props.reply_to,
                     properties=pika.BasicProperties(correlation_id = \
                                                         props.correlation_id),
                     body=str(response))
    ch.basic_ack(delivery_tag=method.delivery_tag)

channel.basic_qos(prefetch_count=1)
channel.basic_consume(queue='game_queue6', on_message_callback=on_request)

print(" [x] Awaiting RPC requests")
channel.start_consuming()