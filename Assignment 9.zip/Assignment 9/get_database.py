from pymongo import MongoClient
import certifi

def get_database():

   #CONNECTION_STRING = (f"mongodb+srv://davianso3:iDMpdYwzF1A50h03@testcluster.n2lvdfx.mongodb.net/?retryWrites=true&w=majority",tlsCAFile=certifi.where())
   client = MongoClient(f"mongodb+srv://davianso2:PuuXYszddULjvcQ1@testcluster.n2lvdfx.mongodb.net/?retryWrites=true&w=majority",tlsCAFile=certifi.where())   
   return client['pet_game_data']
  
if __name__ == "__main__":   
  
   # Get the database
   dbname = get_database()