# Get the database using the method we defined in pymongo_test_insert file
from get_database import get_database

def query_data(game_id):
    dbname = get_database()
    
    collection_name = dbname["game_1_data"]
    
    item_details = collection_name.find_one({"_id": game_id})

    if item_details:
        return item_details
    else:
        print("Item with _id {} not found.".format(game_id))