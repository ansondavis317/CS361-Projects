import pika
import uuid

class GameDataRpcClient(object):

    def __init__(self):
        self.connection = pika.BlockingConnection(
            pika.ConnectionParameters(host='localhost'))

        self.channel = self.connection.channel()

        result = self.channel.queue_declare(queue='', exclusive=True)
        self.callback_queue = result.method.queue

        self.channel.basic_consume(
            queue=self.callback_queue,
            on_message_callback=self.on_response,
            auto_ack=True)

        self.response = None
        self.corr_id = None

    def on_response(self, ch, method, props, body):
        if self.corr_id == props.correlation_id:
            self.response = body

    def call(self, game_id):
        self.response = None
        self.corr_id = str(uuid.uuid4())
        self.channel.basic_publish(
            exchange='',
            routing_key='game_queue6',
            properties=pika.BasicProperties(
                reply_to=self.callback_queue,
                correlation_id=self.corr_id,
                delivery_mode=2,
            ),
            body=str(game_id))
        self.connection.process_data_events(time_limit=None)
        return self.response


game_data_rpc = GameDataRpcClient()

request_type = input('Type "save" to save your game data or "load" to retrieve previously saved data: ')
if request_type == 'load':
    game_id = input("Input your game id to retrieve a specific game you have previously saved:")
    try:
        game_string = f"Game_Id:{game_id}"
        response = game_data_rpc.call(game_string)
        print(f" [.] Got {response}")
    except:
        print("Could not find game: ", game_id)
elif request_type == 'save':
    # test data
    game_data = {
        "_id": 678,
        "saveSlot": 1,
        "petName": "Woofie",
        "health": 10,
        "hunger": 15,
        "thirst": 20,
        "hygiene": 25
    }

    response = game_data_rpc.call(str(game_data))
    print("Game sucessfully saved!")